/* This file will be overwritten by our grading code; don't put anything here */

package com.cs155.evilapp;

public class MessageSender {

	public void SendMessage(String m) {
		// Do nothing
	}
}
